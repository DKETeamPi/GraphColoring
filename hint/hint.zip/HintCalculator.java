import java.util.concurrent.atomic.*;

public class HintCalculator implements Runnable
{
	private int[] coloring;
	private int[] playerColoring;
	private int[] backTrackColoring;
	private int[] compareColoring;
	private AtomicIntegerArray tempPlayerColoring;
	private AtomicIntegerArray tempBackTrackColoring;
	private AtomicBoolean newPlayerColoring;
	private AtomicBoolean newBackTrackColoring;
	private adjGraph graph;
	HintCalculator(tester test,adjGraph graph)
	{
		this.graph=graph;
		coloring = new int[graph.length.length];
		playerColoring = new int[graph.length.length];
		backTrackColoring = new int[graph.length.length];
		compareColoring = new int[graph.length.length];
		tempPlayerColoring = new AtomicIntegerArray(graph.length.length);
		tempBackTrackColoring = new AtomicIntegerArray(graph.length.length);
		newPlayerColoring=new AtomicBoolean(false);
		newBackTrackColoring=new AtomicBoolean(false);
	}
	public void run()
	{
		while(true)
		{
			get();
			for(coloring.length)
			{
				//do kampe chain
			}
			
			
			int i=0;
			boolean equal = true;
			while(equal && i<graph.length.length)
			{
				if (compareColoring[i]!=coloring[i])
				{
					equal=false;
				}
				i++;
			}
			if(equal)
			{
				//sleep
			}
			
		}
	}
	private void get()
	{
		setGetPlayerColoring(null);
		setGetBackTrackColoring(null);
	}
	public void setPlayerColoring(AtomicIntegerArray a)
	{
		setGetPlayerColoring(a);
	}
	public void setBackTrackColoring(AtomicIntegerArray a)
	{
		setGetBackTrackColoring(a);
	}
	public synchronized void setGetPlayerColoring(AtomicIntegerArray a)
	{
		if(a==null)
		{
			if(newPlayerColoring.get())
			{
				newPlayerColoring.set(false);
				for(int i=0;i<playerColoring.length;i++)
				{
					playerColoring[i]=tempPlayerColoring.get(i);
				}
			}
		}
		else
		{
			newPlayerColoring.set(true);
			for(int i=0;i<tempPlayerColoring.length();i++)
			{
				tempPlayerColoring.set(i,a.get(i));
			}
		}
		
	}
	public synchronized void setGetBackTrackColoring(AtomicIntegerArray a)
	{
		if(a==null)
		{
			if (newBackTrackColoring.get())
			{
				newBackTrackColoring.set(false);
				for(int i=0;i<backTrackColoring.length;i++)
				{
					backTrackColoring[i]=tempBackTrackColoring.get(i);
				}
			}
		}
		else
		{
			newBackTrackColoring.set(true);
			for(int i=0;i<tempBackTrackColoring.length();i++)
			{
				tempBackTrackColoring.set(i,a.get(i));
			}
		}
	}
}