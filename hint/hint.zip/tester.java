import java.util.concurrent.atomic.AtomicBoolean;

public class tester
{
	private AtomicBoolean a=new AtomicBoolean(false);
	private int[] ciao=new int[0];
	public static void main(String[] args)
	{
		new tester(args);
	}
	public tester(String[] args)
	{
		adjGraph graph=ReadGraphReverseIndex.main(args);
		HintCalculator hc =new HintCalculator(this,graph.clone());
		System.out.println(this);
		(new Thread(new backTrack(this,graph.clone()))).start();
		while(true)
		{
			if (a.get())
			{
				for(int i=0;i<ciao.length;i++)
				{
					System.out.println(ciao[i]);
				}
				a.set(false);
			}
		}
	}
	public void done(int[] ciao)
	{
		this.ciao=ciao;
		a.set(true);
	}
}